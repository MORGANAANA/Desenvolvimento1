package persistencia;

import modelo.Usuario;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author leonardo
 */
public class UsuarioDAO {
    private Session sessao;
    
    public UsuarioDAO() {
        sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        sessao.beginTransaction();
    }
    
    public void salvar(Usuario u) {
        sessao.saveOrUpdate(u);
    }
    
    public Usuario carregar(int id) {
        return (Usuario) sessao.get(Usuario.class, id);
    }
    
    public void remover(Usuario u) {
        sessao.delete(u);
    }
    
    public void encerrar() {
        sessao.getTransaction().commit();
    }
}
