package control;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.calculoImc;
/**
 *
 * @author 10070185
 */
public class controlServidor extends HttpServlet{
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            calculoImc c = new calculoImc();
            c.setAltura(Float.parseFloat(request.getParameter("altura")));
            c.setPeso(Float.parseFloat(request.getParameter("peso")));
            request.setAttribute("resultado", c.getResultado());
         
        } catch(NumberFormatException e) {
            request.setAttribute("msgErro", "Dados Inválidos!");
        }
        RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
        rd.forward(request, response);
    }
   
 @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    
    
}
