package beans;

import javax.annotation.PreDestroy;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import modelo.Usuario;
import persistencia.UsuarioDAO;

/**
 *
 * @author leonardo
 */
@ManagedBean(name="usuarioBean")
public class CadastroUsuariosBean {
    private Usuario usuario = new Usuario();
    private final UsuarioDAO dao = new UsuarioDAO();

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    public void salvar() {
        dao.salvar(usuario);
        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Usuário incluído com sucesso!", "");
        FacesContext.getCurrentInstance().addMessage(null, msg);
        usuario = new Usuario();
    }
    
    public String carregar() {
        usuario = dao.carregar(usuario.getId());
        if(usuario == null) {
            FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Usuário não encontrado!", "");
            FacesContext.getCurrentInstance().addMessage(null, msg);
            return "consulta1";
        } else {
            return "consulta2";
        }
        
    }
    
    public void remover() {
        dao.remover(usuario);
        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Usuário removido com sucesso!", "");
        FacesContext.getCurrentInstance().addMessage(null, msg);
    }
    
    @PreDestroy
    public void encerrar() {
        dao.encerrar();
    }
}
