/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import javax.annotation.PreDestroy;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import modelo.Livro;
import persistencia.LivroDAO;

/**
 *
 * @author superaluno
 */
@ManagedBean(name = "livroBean")
public class CadastroLivroBean {

    private Livro livro = new Livro();
    private final LivroDAO dao = new LivroDAO();

    public Livro getLivro() {
        return livro;
    }

    public void setLivro(Livro livro) {
        this.livro = livro;
    }
    
    public void salvar() {
        dao.salvar(livro);
        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Livro incluído com sucesso!", "");
        FacesContext.getCurrentInstance().addMessage(null, msg);
        livro = new Livro();
    }
    public void remover() {
        dao.remover(livro);
        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Livro removido com sucesso!", "");
        FacesContext.getCurrentInstance().addMessage(null, msg);
    }
    
    @PreDestroy
    public void encerrar() {
        dao.encerrar();
    }

}
