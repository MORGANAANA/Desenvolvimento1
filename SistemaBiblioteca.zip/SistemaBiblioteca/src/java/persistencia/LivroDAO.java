/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package persistencia;

import modelo.Livro;
import org.hibernate.Session;

/**
 *
 * @author superaluno
 */
public class LivroDAO {

    private Session sessao;

    public LivroDAO() {
        sessao = HibernateUtil.getSessionFactory().getCurrentSession();
        sessao.beginTransaction();
    }
    
    public void salvar(Livro l){
        sessao.saveOrUpdate(l);
    }
    
    public void remover(Livro l){
        sessao.delete(l);
    }
    public void encerrar() {
       sessao.getTransaction().commit();
   }

}
