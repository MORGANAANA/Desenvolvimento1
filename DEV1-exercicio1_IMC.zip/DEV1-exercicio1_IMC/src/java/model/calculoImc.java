
package model;

/**
 *
 * @author 10070185
 */
public class calculoImc {
    private float peso;
    private float altura; 
  

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }
    
    public String getResultado() {
       float r= peso/(altura*altura);       
    if (r < 18.5){
        return "Magreza";
    }    
    if((r > 18.5) && (r < 24.9)){
        return "Saudavél";         
    }
    if((r > 25) && (r < 29.9)){
        return "Sobrepeso"; 
    }
    if((r > 30) && (r < 34.9)){
        return "Obesidade Grau I"; 
    }
    if((r > 35) && (r < 39.9)){
        return "Obesidade Grau II"; 
    }
    else 
   return "Obesidade Grau III"; 
    }

    
}
