/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author mgrosa
 */
@ManagedBean(name = "bean")
@RequestScoped

public class IMCBean {

    private double peso;
    private double altura;

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getIMC() {
        return peso / (altura * altura);
    }

    public String getResultado() {
        double r= getIMC();
        
        if (r < 18.5) {
            return "Magreza";
        }
        if ((r > 18.5) && (r < 24.9)) {
            return "Saudavél";
        }
        if ((r > 25) && (r < 29.9)) {
            return "Sobrepeso";
        }
        if ((r > 30) && (r < 34.9)) {
            return "Obesidade Grau I";
        }
        if ((r > 35) && (r < 39.9)) {
            return "Obesidade Grau II";
        } else {
            return "Obesidade Grau III";
        }
    }

}
